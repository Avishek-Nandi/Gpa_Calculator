Thanks for using GPA Calculator

Step1: Open the installer and install the file in your computer
Step2: Run the .exe file and enjoy.